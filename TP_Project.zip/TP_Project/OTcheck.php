<?php
	session_start();
	
	if( isset($_REQUEST['submit'])){
	$new = $_REQUEST['new'];
		
		if(empty(trim($new))){
			echo "Null submission found!";
		}else{
        header("location: available_Tutors.php");
		}
	}
?>