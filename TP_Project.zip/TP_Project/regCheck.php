<?php
	session_start();
	
	if( isset($_REQUEST['submit'])){
		$uname =  $_REQUEST['uname'];
		$password =  $_REQUEST['password'];
		$password =  $_REQUEST['password'];
		$uemail = $_REQUEST['uemail'];
		$ugender = $_REQUEST['ugender'];
		
		if(empty(trim($uname)) || empty(trim($password)) || empty(trim($password)) || empty(trim($uemail)) || empty(trim($ugender))){
			echo "Null submission found!";
		}else{

			$file = fopen('reg.txt', 'r');
			$user = fread($file, filesize('reg.txt'));
			$data = explode('~~', $user);

			if(trim($data[0]) == $uname && trim($data[1]) == $password && trim($data[2]) == $password && trim($data[3]) == $uemail){
				$_SESSION['uname'] = $uname;
				$_SESSION['pass'] = $password;
				$_SESSION['pass'] = $password;
				$_SESSION['uemail'] = $uemail;
				$_SESSION['ugender'] = $ugender;

				header("location: login.php");
			}else{
				echo "invalid email/password/uname";
			}
		}

	}else{
		//echo "invalid request! please be registered first!";
		header("location: registration.php");
	}
?>